import flet as ft
import time
import threading
from games_data import games

PAGE_SIZE = 12

class ModernAndromuxApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.page.title = "ANDROMUX ORG - Gaming Hub"
        self.page.theme_mode = ft.ThemeMode.DARK
        self.page.padding = 0
        self.page.scroll = ft.ScrollMode.AUTO
        self.page.bgcolor = "#0a0a0a"
        self.page.fonts = {
            "RobotoSlab": "/fonts/RobotoSlab[wght].ttf"
        }
        
        # Variables de estado
        self.current_index = 0
        self.filtered_games = games[:]
        self.selected_platform = "Todas"
        self.is_loading = False
        
        # Colores del tema
        self.colors = {
            "primary": "#00ff88",
            "secondary": "#ff0066",
            "accent": "#00d4ff",
            "background": "#0a0a0a",
            "surface": "#1a1a1a",
            "card": "#151515",
            "text_primary": "#ffffff",
            "text_secondary": "#b0b0b0",
            "border": "#333333"
        }
        
        self.init_ui()
        
    def init_ui(self):
        # Header moderno
        self.create_header()
        
        # Área de búsqueda y filtros
        self.create_search_section()
        
        # Grid de juegos
        self.game_grid = ft.ResponsiveRow(
            spacing=15,
            run_spacing=15,
            expand=True,
        )
        
        # Container para botón "Cargar más"
        self.load_more_container = ft.Container(
            col=12,
            alignment=ft.alignment.center,
            padding=ft.padding.only(top=20, bottom=20)
        )
        
        # Layout principal
        main_content = ft.Container(
            content=ft.Column([
                self.search_section,
                ft.Container(height=20),  # Espaciado
                self.game_grid,
                self.load_more_container
            ], expand=True, spacing=0),
            padding=ft.padding.symmetric(horizontal=20, vertical=10),
            expand=True
        )
        
        self.page.add(main_content)
        self.reset_and_load()
    
    def create_header(self):
        # Logo y título
        logo_section = ft.Row([
            ft.Container(
                content=ft.Icon(ft.Icons.GAMES, color=self.colors["primary"], size=32),
                bgcolor=ft.Colors.with_opacity(0.1, self.colors["primary"]),
                border_radius=12,
                padding=8,
            ),
            ft.Column([
                ft.Text(
                    "ANDROMUX",
                    size=24,
                    weight=ft.FontWeight.BOLD,
                    color=self.colors["primary"],
                ),
                ft.Text(
                    "Gaming Hub",
                    size=12,
                    color=self.colors["text_secondary"],
                )
            ], spacing=2)
        ], spacing=12, alignment=ft.MainAxisAlignment.START)
        
        # Botones sociales mejorados
        social_buttons = self.create_social_buttons()
        
        # Stats section
        stats_section = ft.Row([
            self.create_stat_chip("Juegos", str(len(games))),
            self.create_stat_chip("Plataformas", "5+"),
            self.create_stat_chip("Activo", "24/7"),
        ], spacing=8)
        
        header = ft.Container(
            content=ft.ResponsiveRow([
                ft.Container(logo_section, col={"xs": 12, "md": 4}),
                ft.Container(stats_section, col={"xs": 12, "md": 4}, 
                           alignment=ft.alignment.center),
                ft.Container(social_buttons, col={"xs": 12, "md": 4}, 
                           alignment=ft.alignment.center_right),
            ]),
            bgcolor=ft.Colors.with_opacity(0.8, self.colors["surface"]),
            padding=20,
            border=ft.border.only(bottom=ft.BorderSide(1, self.colors["border"])),
        )
        
        self.page.add(header)
    
    def create_stat_chip(self, label, value):
        return ft.Container(
            content=ft.Column([
                ft.Text(value, size=16, weight=ft.FontWeight.BOLD, 
                       color=self.colors["accent"]),
                ft.Text(label, size=10, color=self.colors["text_secondary"])
            ], spacing=2, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            bgcolor=ft.Colors.with_opacity(0.1, self.colors["accent"]),
            padding=ft.padding.symmetric(horizontal=12, vertical=8),
            border_radius=8,
            border=ft.border.all(1, ft.Colors.with_opacity(0.3, self.colors["accent"]))
        )
    
    def create_social_buttons(self):
        buttons = []
        social_links = [
            {"image": "youtube.png", "url": "https://www.youtube.com/@andromux", "tooltip": "YouTube"},
            {"image": "tiktok.png", "url": "https://tiktok.com/@andromux", "tooltip": "TikTok"},
            {"image": "paypal.png", "url": "https://x.com/andromuxorg", "tooltip": "PayPal"},
        ]
        
        # Botón de ayuda con icono
        help_btn = ft.Container(
            content=ft.Icon(ft.Icons.HELP_OUTLINE, color=self.colors["primary"], size=20),
            bgcolor=ft.Colors.with_opacity(0.1, self.colors["primary"]),
            padding=8,
            border_radius=8,
            border=ft.border.all(1, ft.Colors.with_opacity(0.3, self.colors["primary"])),
            on_click=lambda e: self.page.launch_url("https://www.andromux.org/"),
            animate=ft.animation.Animation(200, ft.AnimationCurve.EASE_IN_OUT),
        )
        buttons.append(help_btn)
        
        # Botones con imágenes de assets
        for social in social_links:
            btn = ft.Container(
                content=ft.Image(
                    src=social["image"],
                    width=20,
                    height=20
                ),
                bgcolor=ft.Colors.with_opacity(0.1, self.colors["text_primary"]),
                padding=8,
                border_radius=8,
                border=ft.border.all(1, ft.Colors.with_opacity(0.3, self.colors["text_primary"])),
                on_click=lambda e, url=social["url"]: self.page.launch_url(url),
                animate=ft.animation.Animation(200, ft.AnimationCurve.EASE_IN_OUT),
                tooltip=social["tooltip"]
            )
            buttons.append(btn)
        
        return ft.Row(buttons, spacing=8)
    
    def create_search_section(self):
        # Campo de búsqueda mejorado
        self.search_field = ft.TextField(
            hint_text="🔍 Buscar tu juego favorito...",
            on_change=self.on_search_change,
            border_radius=15,
            bgcolor=self.colors["surface"],
            color=self.colors["text_primary"],
            border_color=ft.Colors.with_opacity(0.3, self.colors["primary"]),
            focused_border_color=self.colors["primary"],
            hint_style=ft.TextStyle(color=self.colors["text_secondary"]),
            prefix_icon=ft.Icons.SEARCH,
            suffix=ft.IconButton(
                icon=ft.Icons.CLEAR,
                on_click=self.clear_search,
                icon_color=self.colors["text_secondary"]
            ),
            height=50,
        )
        
        # Filtros de plataforma
        platform_chips = self.create_platform_filters()
        
        self.search_section = ft.Container(
            content=ft.Column([
                self.search_field,
                ft.Container(height=15),
                ft.Text("Plataformas", size=16, weight=ft.FontWeight.BOLD, 
                       color=self.colors["text_primary"]),
                ft.Container(height=8),
                platform_chips,
            ], spacing=0),
            padding=ft.padding.symmetric(vertical=15),
        )
    
    def create_platform_filters(self):
        platforms = ["Todas"] + list(set(game["platform"] for game in games))
        chips = []
        
        for platform in platforms:
            is_selected = platform == self.selected_platform
            chip = ft.Container(
                content=ft.Text(
                    platform,
                    color=self.colors["background"] if is_selected else self.colors["text_secondary"],
                    size=12,
                    weight=ft.FontWeight.BOLD if is_selected else ft.FontWeight.NORMAL
                ),
                bgcolor=self.colors["primary"] if is_selected else ft.Colors.with_opacity(0.1, self.colors["text_secondary"]),
                padding=ft.padding.symmetric(horizontal=16, vertical=8),
                border_radius=20,
                border=ft.border.all(1, self.colors["primary"] if is_selected else self.colors["border"]),
                on_click=lambda e, p=platform: self.filter_by_platform(p),
                animate=ft.animation.Animation(200, ft.AnimationCurve.EASE_IN_OUT),
            )
            chips.append(chip)
        
        return ft.Row(chips, spacing=8, scroll=ft.ScrollMode.AUTO)
    
    def filter_by_platform(self, platform):
        if self.selected_platform != platform:
            self.selected_platform = platform
            # Actualizar solo los chips de filtro
            self.search_section.content.controls[3] = self.create_platform_filters()
            self.search_section.update()
            self.reset_and_load()
    
    def clear_search(self, e):
        self.search_field.value = ""
        self.reset_and_load()
        self.search_field.update()
    
    def on_search_change(self, e):
        # Debounce para búsqueda
        if hasattr(self, 'search_timer'):
            self.search_timer.cancel()
        self.search_timer = threading.Timer(0.5, self.reset_and_load)
        self.search_timer.start()
    
    def reset_and_load(self, e=None):
        query = self.search_field.value.lower() if self.search_field.value else ""
        
        # Filtrar por búsqueda y plataforma
        self.filtered_games = []
        for g in games:
            matches_search = (
                query in str(g.get("id", "")).lower() or
                query in g["title"].lower() or
                query in g["platform"].lower()
            )
            matches_platform = (
                self.selected_platform == "Todas" or 
                g["platform"] == self.selected_platform
            )
            
            if matches_search and matches_platform:
                self.filtered_games.append(g)
        
        self.current_index = 0
        self.game_grid.controls.clear()
        self.load_more()
    
    def load_more(self):
        if self.is_loading:
            return
            
        self.is_loading = True
        
        # Mostrar indicador de carga
        loading_indicator = ft.Container(
            content=ft.Column([
                ft.ProgressRing(
                    width=40,
                    height=40,
                    stroke_width=3,
                    color=self.colors["primary"]
                ),
                ft.Text("Cargando juegos...", 
                       color=self.colors["text_secondary"], size=12)
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10),
            alignment=ft.alignment.center,
            col=12,
            padding=30
        )
        
        self.load_more_container.content = loading_indicator
        self.load_more_container.update()
        
        def load_data():
            time.sleep(0.8)  # Simular carga
            
            start = self.current_index
            end = start + PAGE_SIZE
            batch = self.filtered_games[start:end]
            
            # Agregar nuevas cards con animación
            for i, game in enumerate(batch):
                card = self.create_modern_game_card(game, i)
                self.game_grid.controls.append(card)
            
            self.current_index += len(batch)
            
            # Actualizar botón "Cargar más"
            if self.current_index < len(self.filtered_games):
                load_more_btn = ft.Container(
                    content=ft.ElevatedButton(
                        content=ft.Row([
                            ft.Icon(ft.Icons.ADD, size=16),
                            ft.Text("Cargar más juegos", size=14, weight=ft.FontWeight.BOLD)
                        ], spacing=8, alignment=ft.MainAxisAlignment.CENTER),
                        on_click=lambda e: self.load_more(),
                        style=ft.ButtonStyle(
                            bgcolor=ft.Colors.with_opacity(0.1, self.colors["primary"]),
                            color=self.colors["primary"],
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(horizontal=30, vertical=15),
                            side=ft.BorderSide(1, self.colors["primary"]),
                            overlay_color=ft.Colors.with_opacity(0.1, self.colors["primary"]),
                        ),
                    ),
                    col=12,
                    alignment=ft.alignment.center,
                    padding=20
                )
                self.load_more_container.content = load_more_btn
            else:
                # Mostrar mensaje de fin
                self.load_more_container.content = ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.DONE_ALL, 
                               color=self.colors["primary"], size=32),
                        ft.Text("¡Has visto todos los juegos!", 
                               color=self.colors["text_secondary"], 
                               text_align=ft.TextAlign.CENTER)
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10),
                    col=12,
                    alignment=ft.alignment.center,
                    padding=30
                )
            
            self.is_loading = False
            self.game_grid.update()
            self.load_more_container.update()
        
        threading.Thread(target=load_data, daemon=True).start()
    
    def create_modern_game_card(self, game, index=0):
        # Card con efecto glassmorphism
        card_content = ft.Container(
            content=ft.Column([
                # Imagen con overlay
                ft.Container(
                    content=ft.Stack([
                        ft.Image(
                            src=game["image"],
                            width=200,
                            height=160,
                            fit=ft.ImageFit.COVER,
                            border_radius=ft.border_radius.only(
                                top_left=12, top_right=12
                            ),
                        ),
                        # Overlay con gradiente
                        ft.Container(
                            bgcolor=ft.Colors.with_opacity(0.3, "#000000"),
                            border_radius=ft.border_radius.only(
                                top_left=12, top_right=12
                            ),
                        ),
                        # Platform badge
                        ft.Container(
                            content=ft.Text(
                                game['platform'],
                                size=10,
                                weight=ft.FontWeight.BOLD,
                                color="#000000"
                            ),
                            bgcolor=self.colors["accent"],
                            padding=ft.padding.symmetric(horizontal=8, vertical=4),
                            border_radius=8,
                            top=10,
                            right=10,
                        )
                    ]),
                    height=160,
                ),
                # Información del juego
                ft.Container(
                    content=ft.Column([
                        ft.Text(
                            game['title'],
                            weight=ft.FontWeight.BOLD,
                            size=13,
                            color=self.colors["text_primary"],
                            max_lines=2,
                            overflow=ft.TextOverflow.ELLIPSIS,
                        ),
                        ft.Row([
                            ft.Icon(ft.Icons.DOWNLOAD, 
                                   color=self.colors["primary"], size=14),
                            ft.Text("Descargar", 
                                   size=11, 
                                   color=self.colors["primary"],
                                   weight=ft.FontWeight.BOLD)
                        ], spacing=4, alignment=ft.MainAxisAlignment.CENTER)
                    ], spacing=8),
                    padding=15,
                )
            ], spacing=0),
            bgcolor=ft.Colors.with_opacity(0.05, self.colors["text_primary"]),
            border=ft.border.all(1, ft.Colors.with_opacity(0.1, self.colors["text_primary"])),
            border_radius=12,
            animate=ft.animation.Animation(300, ft.AnimationCurve.EASE_OUT),
            animate_scale=ft.animation.Animation(200, ft.AnimationCurve.EASE_IN_OUT),
            on_click=lambda e: self.open_game_details(game),
            ink=True,
        )
        
        return ft.Container(
            content=card_content,
            col={"xs": 12, "sm": 6, "md": 4, "lg": 3, "xl": 2},
            animate_opacity=300,
            animate_offset=ft.animation.Animation(400 + index * 100, ft.AnimationCurve.EASE_OUT),
        )
    
    def open_game_details(self, game):
        # Modal con detalles del juego
        def close_modal(e):
            modal.open = False
            self.page.update()
        
        modal_content = ft.Container(
            content=ft.Column([
                # Header del modal
                ft.Row([
                    ft.Text("Detalles del Juego", 
                           size=20, 
                           weight=ft.FontWeight.BOLD,
                           color=self.colors["text_primary"]),
                    ft.IconButton(
                        icon=ft.Icons.CLOSE,
                        on_click=close_modal,
                        icon_color=self.colors["text_secondary"]
                    )
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                
                ft.Divider(color=self.colors["border"]),
                
                # Contenido del modal
                ft.Row([
                    ft.Image(
                        src=game["image"],
                        width=120,
                        height=120,
                        fit=ft.ImageFit.COVER,
                        border_radius=10,
                    ),
                    ft.Column([
                        ft.Text(game['title'], 
                               size=16, 
                               weight=ft.FontWeight.BOLD,
                               color=self.colors["text_primary"]),
                        ft.Text(f"Plataforma: {game['platform']}", 
                               color=self.colors["text_secondary"]),
                        ft.Text(f"ID: {game['id']}", 
                               color=self.colors["text_secondary"]),
                    ], spacing=8, expand=True)
                ], spacing=20),
                
                # Descripción del juego
                ft.Container(
                    content=ft.Column([
                        ft.Text("Descripción:", 
                               size=14, 
                               weight=ft.FontWeight.BOLD,
                               color=self.colors["text_primary"]),
                        ft.Text(
                            game.get('description', 'Descripción no disponible para este juego.'), 
                            size=12,
                            color=self.colors["text_secondary"],
                            max_lines=4,
                            overflow=ft.TextOverflow.ELLIPSIS
                        ),
                    ], spacing=5),
                    bgcolor=ft.Colors.with_opacity(0.05, self.colors["text_primary"]),
                    padding=15,
                    border_radius=10,
                    border=ft.border.all(1, ft.Colors.with_opacity(0.1, self.colors["text_primary"]))
                ),
                
                # Botón de descarga
                ft.Container(
                    content=ft.ElevatedButton(
                        content=ft.Row([
                            ft.Icon(ft.Icons.DOWNLOAD, size=16),
                            ft.Text("Descargar Ahora")
                        ], spacing=8, alignment=ft.MainAxisAlignment.CENTER),
                        on_click=lambda e: self.page.launch_url(game["url"]),
                        style=ft.ButtonStyle(
                            bgcolor=self.colors["primary"],
                            color="#000000",
                            shape=ft.RoundedRectangleBorder(radius=8),
                            padding=ft.padding.symmetric(horizontal=20, vertical=12)
                        ),
                        width=200
                    ),
                    alignment=ft.alignment.center
                )
            ], spacing=15),
            bgcolor=self.colors["surface"],
            padding=20,
            border_radius=15,
            border=ft.border.all(1, self.colors["border"]),
            width=550,
            height=400,
        )
        
        modal = ft.AlertDialog(
            modal=True,
            content=modal_content,
            bgcolor=ft.Colors.TRANSPARENT,
        )
        
        self.page.overlay.append(modal)
        modal.open = True
        self.page.update()

def main(page: ft.Page):
    ModernAndromuxApp(page)

ft.app(target=main, assets_dir="assets")